## Install Redhat Single Sign 7.4 integration with Redhat Datagrid 8.0 on OCP 4.x

Some preqrequisites for SSO setup.
<ol>
<li>SSO-extentions cli for cache creation in sso.</li>
<li>Datasource module details.</li>
<li>Datasource Module jar.</li>
<li>Datagrid service url.</li>
</ol>


### Datagrid setup
      Login in openshift console
      Menu-> operator hub -> search-> Redhat Datagrid -> Install operator->approval strategy->automatic

      Menu-> Installed Operator-> Redhat Data-grid-> Create infnispan-> Edit yml -> add replicas 3


###### Create caches in RHDG
![alt text](https://github.com/adam-p/markdown-here/raw/master/src/common/images/icon48.png "Logo Title Text 1") Login into any pod for caches creation. All the 3 pods are in cluster mode so we do not need to create cache for every pod ony one pod will replicate the caches into another pods.

       oc get pods there will be 3 pods
       oc rsh rhsso-infinispan-0
       #cd /opt/Infinispan/bin
       #./cli.sh -c ip:port
       #[rhsso-infinispan-0-10071@infinispan//containers/default]> create cache --template=org.infinispan.REPL_SYNC work
       #[rhsso-infinispan-0-10071@infinispan//containers/default]> create cache --template=org.infinispan.DIST_ASYNC clientSessions
       #[rhsso-infinispan-0-10071@infinispan//containers/default]> create cache --template=org.infinispan.DIST_ASYNC offlineSessions
       #[rhsso-infinispan-0-10071@infinispan//containers/default]> create cache --template=org.infinispan.DIST_ASYNC offlineClientSessions
       #[rhsso-infinispan-0-10071@infinispan//containers/default]> create cache --template=org.infinispan.DIST_ASYNC actionTokens
       #[rhsso-infinispan-0-10071@infinispan//containers/default]> create cache --template=org.infinispan.DIST_ASYNC loginFailures
       #[rhsso-infinispan-0-10071@infinispan//containers/default]> create cache --template=org.infinispan.DIST_ASYNC sessions


![alt text](https://github.com/adam-p/markdown-here/raw/master/src/common/images/icon48.png "Logo Title Text 1") Infinispan.xml is attached in REPOSITORY.

    oc edit configmap infinispan
     disable endpoints authentication
     endpoints:
        hotrod:
          auth: false
        rest:
          auth: false

##### Copy datagrid service name

     oc get services

     Copy the infinispan service name which will used in SSO configuration.




### RHSSO setup

Git clone rhsso-templates from below Link
       https://github.com/jboss-container-images/redhat-sso-7-openshift-image/tree/sso74-dev/docs

##### Import template sso74-x509-https.json in openshift if you do not want to use certificates.
    root@LAPTOP-S928577R:~/git_repo/redhat-sso-7-openshift-image/templates# oc create -f sso74-x509-https.json -n openshift
    template.template.openshift.io/sso74-x509-https created

##### Import template sso74-https.json If you want to use secure connection.
    root@LAPTOP-S928577R:~/git_repo/redhat-sso-7-openshift-image/templates# oc create -f sso74-https.json -n openshift
    template.template.openshift.io/sso74-https created

##### Import image in Openshift namespace from Redhat repository.
    root@LAPTOP-S928577R:~/git_repo/certs# oc import-image rh-sso-7/sso74-openshift-rhel8 --from=registry.redhat.io/rh-sso-7/sso74-openshift-rhel8 --confirm -n openshift

###### Verify image

     oc get is sso74-openshift-rhel8  -n openshift

##### Edit template with latest image of RHSSO
     oc edit template sso74-https -n openshift
    Edit tirgger image tag  (kind: ImageStreamTag name: sso74-openshift-rhel8:latest) from 7.4 to latest

##### create sso-extensions.cli for custom changes.
    Add jar into extions (In the https-sso template postgres jar is already added into template modules)
    Add module for datasources(In the https-sso template postgres jar is already added into template modules)
    Create datasource with your url
    Add socket binding
    Add remote-store into 7 caches.
    Add site name

##### Create secret for secure connection
      #req -new -newkey rsa:4096 -x509 -keyout xpaas.key -out xpaas.crt -days 365 -subj "/CN=xpaas-sso.ca"
      #openssl req -new -newkey rsa:4096 -x509 -keyout xpaas.key -out xpaas.crt -days 365 -subj "/CN=xpaas-sso.ca"
      #keytool -genkeypair -keyalg RSA -keysize 2048 -dname "CN=secure-sso-rhsso-np.apps.ocplife-np.bajajallianz.com" -alias jboss -keystore keystore.jks
      #keytool -certreq -keyalg rsa -alias rhsso -keystore keystore.jks -file sso.csr
      #keytool -genkeypair -keyalg RSA -keysize 2048 -dname "CN=secure-sso-rhsso-np.apps.ocptest.com" -alias rhsso -keystore keystore.jks

      #openssl x509 -req -CA xpaas.crt -CAkey xpaas.key -in sso.csr -out sso.crt -days 365 -CAcreateserial
      #keytool -import -file sso.crt -alias rhsso -keystore keystore.jks
      #keytool -genseckey -alias secret-key -storetype JCEKS -keystore jgroups.jceks
      #keytool -import -file xpaas.crt -alias xpaas.ca -keystore truststore.jks

###### Create secret for SSO_TRUSTSTORE and JKS files
      oc create secret generic rhsso-secret --from-file=keystore.jks --from-file=jgroups.jceks --from-file=truststore.jks
      oc project
      oc get secret

###### Link the secret with default service account in RHSSO

        oc secrets link default rhsso-secret


##### Create new build for custom cli changes into sso.
     oc new-build --name=sso74 --binary --strategy=docker -n openshift
##### Start Build
     oc start-build sso74 --from-dir=. --follow -n openshift

##### Edit template of RHSSO in openshift namespaces with changes of your lastet image of build with oc-build
     oc edit template sso74-https -n openshift

     Replace image name in triggers
    triggers:
       ......
       from:
         kind: ImageStreamTag
         name: sso74:latest    

##### Create New-app


     root@LAPTOP-S928577R:~/git_repo/certs# root@LAPTOP-S928577R:~/rhsso# oc new-app --name=nonprod-sso --template=sso74-https -p HTTPS_SECRET="rhsso-secret" -p HTTPS_KEYSTORE="keystore.jks"  -p HTTPS_NAME="rhsso" -p HTTPS_PASSWORD="redhat"  -p JGROUPS_ENCRYPT_SECRET="rhsso-secret"  -p JGROUPS_ENCRYPT_KEYSTORE="jgroups.jceks"  -p JGROUPS_ENCRYPT_NAME="secret-key"  -p JGROUPS_ENCRYPT_PASSWORD="redhat"  -p SSO_ADMIN_USERNAME="admin" -p SSO_ADMIN_PASSWORD="admin@123" -p SSO_REALM="openshift"  -p SSO_TRUSTSTORE="truststore.jks"  -p SSO_TRUSTSTORE_PASSWORD="redhat" -p SSO_TRUSTSTORE_SECRET="rhsso-secret"


     --> Deploying template "openshift/sso74-https" to project rhsso-np

       Red Hat Single Sign-On 7.4 on OpenJDK (Ephemeral with passthrough TLS)
       ---------
       An example application based on RH-SSO 7.4 on OpenJDK image. For more information about using this template, see https://github.com/jboss-container-images/redhat-sso-7-openshift-image/tree/sso74-dev/docs.

       A new RH-SSO service has been created in your project. The admin username/password for accessing the master realm via the RH-SSO console is admin/admin@123. Please be sure to create the following secrets: "rhsso-secret" containing the keystore.jks file used for serving secure content; "rhsso-secret" containing the jgroups.jceks file used for securing JGroups communications; "rhsso-secret" containing the truststore.jks file used for securing RH-SSO requests.

       * With parameters:
          * Application Name=sso
          * Custom http Route Hostname=
          * Custom https Route Hostname=
          * Custom RH-SSO Server Hostname=
          * Server Keystore Secret Name=rhsso-secret
          * Server Keystore Filename=keystore.jks
          * Server Keystore Type=
          * Server Certificate Name=rhsso
          * Server Keystore Password=redhat
          * Datasource Minimum Pool Size=
          * Datasource Maximum Pool Size=
          * Datasource Transaction Isolation=
          * JGroups Secret Name=rhsso-secret
          * JGroups Keystore Filename=jgroups.jceks
          * JGroups Certificate Name=secret-key
          * JGroups Keystore Password=redhat
          * JGroups Cluster Password=xTW5TJmv # generated
          * ImageStream Namespace=openshift
          * RH-SSO Administrator Username=admin
          * RH-SSO Administrator Password=admin@123
          * RH-SSO Realm=openshift
          * RH-SSO Service Username=
          * RH-SSO Service Password=
          * RH-SSO Trust Store=truststore.jks
          * RH-SSO Trust Store Password=redhat
          * RH-SSO Trust Store Secret=rhsso-secret
          * Container Memory Limit=1Gi

      --> Creating resources ...
          service "sso" created
          service "secure-sso" created
          service "sso-ping" created
          route.route.openshift.io "sso" created
          route.route.openshift.io "secure-sso" created
          deploymentconfig.apps.openshift.io "sso" created
      --> Success
          Access your application via route 'sso-rhsso-np.apps.ocptest.com'
          Access your application via route 'secure-sso-rhsso-np.apps.ocptest.com'
          Run 'oc status' to view your app.


##### Get route of SSO
      oc get routes
      copy sso secure route and browse it and login with credentials given above
      username: admin
      password: admin@123
