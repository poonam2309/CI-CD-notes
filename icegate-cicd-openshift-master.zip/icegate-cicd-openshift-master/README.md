This repository contains all the artifacts related to Jenkins CICD for Backend (Spring Boot) application as well as Frontend (Angular 9) application.

This includes:

1. Dockerfile for customizing the jenkins agent from maven base image and add docker steps.
2. Jenkinsfile for DEV, SIT, UAT, TRAINING and PT environments of Backend application.
3. Jenkinsfile for Frontend angular 9 application.
4. Custom template.json containing all the dev environment kubernetes resources for fine-grained controll of resources.
5. setting.xml containing entries related to Nexus.
6. pom.xml containing entry related to Nexus DistributionManagement.
7. Custom templateUat.json for SIT and UAT environment.
8. package.json containing all the packages and nexus related entries.
