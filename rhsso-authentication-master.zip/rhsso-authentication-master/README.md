# Auth require group extension

This extension provides an authentication action that will require a user to be part of a specified group.
## Maven package the code 

mvn clean package

## Installation

Copy the JAR into `/opt/jboss/keycloak/standalone/deployments/`

## Configure

- Copy the `Browser` authentication 
- Add a new execution, select "Required Group"
- Click the newly added execution and specify the group that has access
- On your restricted clients, set this authentication in browser flows


## Demo

User `in_group` is in the allowed group and can login, user `not_in_group` is not in the allowed group and gets a message stating no access.

## Reference link :

https://github.com/thomasdarimont/keycloak-extension-playground

## Quickstart for this testing 

app-profile-jee-jsp (all role accessible)

https://github.com/redhat-developer/redhat-sso-quickstarts

## Doc link conflunce page

https://redhat-consulting-india.atlassian.net/l/c/P9q8Aftx